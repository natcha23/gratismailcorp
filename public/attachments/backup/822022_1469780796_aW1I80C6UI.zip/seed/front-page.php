<?php get_header(); ?>

<main id="main" class="site-main" role="main">


	<div class="site-banner">
		<?php 
			if (is_active_sidebar( 'banner' )) {
				dynamic_sidebar( 'banner' );
			} else {
				if (get_header_image() != '') { echo '<img src="' . get_header_image() . '" alt="banner">';}
			}
		?>
	</div>


	<div class="home-section -main">
		<div class="container">
			<?php while ( have_posts() ) : the_post(); ?>

				<?php the_content(); ?>

			<?php endwhile; ?>
		</div><!--container-->
	</div><!--home-section-->



	<?php /*
		<div class="home-section -news">
			<div class="container">
				<h2>Recent News</h2>
				<?php 
					$args = array(
						// 'post_type' => 'post',
						// 'category_name' => 'news',
						'posts_per_page' => 4
						);
					$the_query = new WP_Query( $args );
				?>

				<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>

				<?php get_template_part( 'template-parts/content', '' ); ?>

				<?php endwhile; wp_reset_postdata(); ?>
			</div><!--container-->
		</div><!--home-section-->
		*/
	?>

	</main><!--.site-main-->

	<?php get_footer(); ?>