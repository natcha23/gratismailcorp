<?php get_header(); ?>
<div class="main-header">
	<div class="container">
		<h2 class="main-title"><a href="<?php echo get_permalink( woocommerce_get_page_id( 'shop' ) );?>"><?php _e( 'Shop', 'seed' ); ?></a></h2>
	</div>
</div>

<div class="container">
	<div id="primary" class="content-area">
		<main id="main" class="site-main -hide-title" role="main">
			

				<?php woocommerce_content(); ?>

			
		</main><!-- #main -->
	</div><!-- #primary -->
</div><!--.container-->
<?php get_footer(); ?>
