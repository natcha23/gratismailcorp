/**
 * main.js
 *
 * For all custom js codes.
 */

jQuery(document).ready(function($) {  

	$.slidebars();

	$('.site-mobile-navigation .menu-item-has-children').append('<i class="si-caret-down"></i>');
	
	$('.site-mobile-navigation .menu-item-has-children > i').click(function () {                
		$(this).parent().toggleClass('active');        
	});
	



	/*
	$('.owl-carousel').owlCarousel({
	    loop:true,
	    nav:true,
	    navText: ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
	    smartSpeed: 600,
	    autoplay:true,
  		autoplayTimeout:4000,
  		autoplayHoverPause:true,
	    items:1,
	});
	*/

});
